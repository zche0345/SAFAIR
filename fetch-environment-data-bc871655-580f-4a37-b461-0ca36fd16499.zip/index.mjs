import { DynamoDBClient, PutItemCommand } from '@aws-sdk/client-dynamodb'
import { marshall } from '@aws-sdk/util-dynamodb'

const ddb = new DynamoDBClient({})

const TABLE_NAME = process.env.TABLE_NAME || 'air_snapshot'
const LOCATION = process.env.LOCATION || 'melbourne'
const LATITUDE = Number(process.env.LATITUDE || -37.8136)
const LONGITUDE = Number(process.env.LONGITUDE || 144.9631)
const TIMEZONE = process.env.TIMEZONE || 'Australia/Sydney'

const AIR_API = 'https://air-quality-api.open-meteo.com/v1/air-quality'
const WEATHER_API = 'https://api.open-meteo.com/v1/forecast'

function pickLatestPastHourIndex(times, nowIso) {
  const now = new Date(nowIso).getTime()
  let bestIdx = 0
  let bestTime = -Infinity

  for (let i = 0; i < times.length; i++) {
    const t = new Date(times[i]).getTime()
    if (t <= now && t > bestTime) {
      bestTime = t
      bestIdx = i
    }
  }

  // Fallback if all times are in the future (edge case)
  return bestTime === -Infinity ? 0 : bestIdx
}

function riskFromAqi(aqi) {
  if (aqi == null || Number.isNaN(aqi)) {
    return {
      aqiLabel: 'Unknown',
      statusTitle: 'Air Risk Unavailable',
      statusSummary:
        'We could not determine air risk right now. Please use extra caution outdoors.',
      theme: 'amber',
    }
  }
  if (aqi <= 50) {
    return {
      aqiLabel: 'Good',
      statusTitle: 'Low Asthma Risk',
      statusSummary:
        'Air conditions are generally favorable. Normal outdoor activities are usually okay.',
      theme: 'mint',
    }
  }
  if (aqi <= 100) {
    return {
      aqiLabel: 'Moderate',
      statusTitle: 'Moderate Asthma Risk',
      statusSummary:
        'Some environmental factors may affect sensitive breathing. Consider simple precautions.',
      theme: 'amber',
    }
  }
  if (aqi <= 150) {
    return {
      aqiLabel: 'Unhealthy for Sensitive Groups',
      statusTitle: 'High Asthma Risk',
      statusSummary:
        'Air conditions may trigger symptoms. Limit strenuous outdoor activity where possible.',
      theme: 'pink',
    }
  }
  return {
    aqiLabel: 'Unhealthy',
    statusTitle: 'Very High Asthma Risk',
    statusSummary:
      'Air conditions are poor. Prefer indoor activities and follow your asthma action plan.',
    theme: 'pink',
  }
}

function buildRecommendations(aqi, ozone, no2) {
  const list = []
  if ((aqi ?? 0) > 100) {
    list.push('Choose indoor activities today, especially in the afternoon.')
  } else if ((aqi ?? 0) > 50) {
    list.push('Keep outdoor sessions shorter and lower intensity.')
  } else {
    list.push('Outdoor activity is generally suitable for most families today.')
  }

  if ((ozone ?? 0) >= 120) {
    list.push('Avoid high-intensity exercise during peak afternoon hours.')
  }
  if ((no2 ?? 0) >= 100) {
    list.push('Prefer routes and parks away from heavy traffic.')
  }

  list.push('Carry the reliever inhaler when leaving home.')
  return list
}

function windLabel(speedKmh) {
  if (speedKmh == null) return 'Unknown'
  if (speedKmh < 10) return 'Light'
  if (speedKmh < 25) return 'Moderate'
  return 'Strong'
}

export const handler = async () => {
  const nowIso = new Date().toISOString()

  const airUrl =
    `${AIR_API}?latitude=${LATITUDE}&longitude=${LONGITUDE}` +
    `&hourly=pm2_5,pm10,ozone,nitrogen_dioxide,us_aqi` +
    `&timezone=${encodeURIComponent(TIMEZONE)}`

  const weatherUrl =
    `${WEATHER_API}?latitude=${LATITUDE}&longitude=${LONGITUDE}` +
    `&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m,uv_index` +
    `&timezone=${encodeURIComponent(TIMEZONE)}`

  const [airRes, weatherRes] = await Promise.all([fetch(airUrl), fetch(weatherUrl)])
  if (!airRes.ok) throw new Error(`Air API failed: ${airRes.status}`)
  if (!weatherRes.ok) throw new Error(`Weather API failed: ${weatherRes.status}`)

  const air = await airRes.json()
  const weather = await weatherRes.json()

  const airTimes = air?.hourly?.time || []
  const weatherTimes = weather?.hourly?.time || []

  if (!airTimes.length || !weatherTimes.length) {
    throw new Error('No hourly data returned from upstream APIs')
  }

  const airIdx = pickLatestPastHourIndex(airTimes, nowIso)
  const weatherIdx = pickLatestPastHourIndex(weatherTimes, nowIso)

  const sourceTime = airTimes[airIdx]
  const ageMinutes = Math.max(
    0,
    Math.round((Date.now() - new Date(sourceTime).getTime()) / 60000)
  )
  const isDelayed = ageMinutes > 90

  const pm25 = air.hourly.pm2_5?.[airIdx] ?? null
  const pm10 = air.hourly.pm10?.[airIdx] ?? null
  const ozone = air.hourly.ozone?.[airIdx] ?? null
  const no2 = air.hourly.nitrogen_dioxide?.[airIdx] ?? null
  const aqi = air.hourly.us_aqi?.[airIdx] ?? null

  const temperatureC = weather.hourly.temperature_2m?.[weatherIdx] ?? null
  const humidityPct = weather.hourly.relative_humidity_2m?.[weatherIdx] ?? null
  const windKmh = weather.hourly.wind_speed_10m?.[weatherIdx] ?? null
  const uvIndex = weather.hourly.uv_index?.[weatherIdx] ?? null

  const risk = riskFromAqi(aqi)
  const recommendations = buildRecommendations(aqi, ozone, no2)

  const item = {
    location: LOCATION, // Partition key
    timestamp: nowIso, // Sort key
    sourceTime,
    sourceAgeMinutes: ageMinutes, // stored for audit/debug
    isDelayed, // stored for audit/debug
    aqi,
    aqiLabel: risk.aqiLabel,
    statusTitle: risk.statusTitle,
    statusSummary: risk.statusSummary,
    theme: risk.theme,
    pollutants: { pm25, pm10, ozone, no2 },
    weather: {
      temperatureC,
      humidityPct,
      windKmh,
      windLabel: windLabel(windKmh),
      uvIndex,
    },
    recommendations,
    provider: 'open-meteo',
    createdAt: nowIso,
  }

  await ddb.send(
    new PutItemCommand({
      TableName: TABLE_NAME,
      Item: marshall(item, { removeUndefinedValues: true }),
    })
  )

  return {
    statusCode: 200,
    body: JSON.stringify({
      ok: true,
      location: LOCATION,
      timestamp: nowIso,
      aqi,
      aqiLabel: risk.aqiLabel,
      isDelayed,
    }),
  }
}
