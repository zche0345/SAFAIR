const DEFAULT_LOCATION = process.env.DEFAULT_LOCATION || 'melbourne'
const DEFAULT_LATITUDE = Number(process.env.DEFAULT_LATITUDE || -37.8136)
const DEFAULT_LONGITUDE = Number(process.env.DEFAULT_LONGITUDE || 144.9631)
const DEFAULT_TIMEZONE = process.env.DEFAULT_TIMEZONE || 'Australia/Sydney'

const AIR_API = 'https://air-quality-api.open-meteo.com/v1/air-quality'

const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  },
  body: JSON.stringify(body),
})

const LOCATION_CONFIG = {
  melbourne: {
    latitude: -37.8136,
    longitude: 144.9631,
    timezone: 'Australia/Sydney',
  },
}

const WINDOWS = [
  { label: '06:00-10:00', startHour: 6, endHour: 10 },
  { label: '10:00-14:00', startHour: 10, endHour: 14 },
  { label: '14:00-18:00', startHour: 14, endHour: 18 },
  { label: '18:00-22:00', startHour: 18, endHour: 22 },
]

function toNumber(v) {
  return typeof v === 'number' && Number.isFinite(v) ? v : null
}

function normalizeAqi(aqi) {
  if (aqi == null) return 60
  return Math.min(Math.max(aqi, 0), 200) / 200
}

function normalizePm25(pm25) {
  if (pm25 == null) return 0.4
  return Math.min(Math.max(pm25, 0), 75) / 75
}

function normalizeOzone(ozone) {
  if (ozone == null) return 0.4
  return Math.min(Math.max(ozone, 0), 240) / 240
}

function normalizeNo2(no2) {
  if (no2 == null) return 0.3
  return Math.min(Math.max(no2, 0), 200) / 200
}

function scoreHour({ aqi, pm25, ozone, no2 }) {
  const score =
    normalizeAqi(aqi) * 0.5 +
    normalizePm25(pm25) * 0.25 +
    normalizeOzone(ozone) * 0.15 +
    normalizeNo2(no2) * 0.1
  return Number(score.toFixed(4))
}

function levelFromScore(score) {
  if (score <= 0.35) return 'safe'
  if (score <= 0.6) return 'caution'
  return 'avoid'
}

function reasonFromData(avg) {
  const parts = []
  if (avg.aqi != null && avg.aqi > 100) parts.push('higher AQI')
  if (avg.pm25 != null && avg.pm25 > 35) parts.push('elevated PM2.5')
  if (avg.ozone != null && avg.ozone > 120) parts.push('higher ozone')
  if (avg.no2 != null && avg.no2 > 100) parts.push('higher NO2')
  if (!parts.length) return 'Lower pollutant levels in this window'
  return parts.join(' and ')
}

function parseHourLocal(timeIsoLike) {
  return Number(timeIsoLike.slice(11, 13))
}

function parseDateLocal(timeIsoLike) {
  return timeIsoLike.slice(0, 10)
}

function avg(values) {
  const nums = values.filter((v) => typeof v === 'number' && Number.isFinite(v))
  if (!nums.length) return null
  return nums.reduce((a, b) => a + b, 0) / nums.length
}

function recommendationFromWindow(window) {
  if (window.level === 'safe') {
    return {
      level: 'safe',
      timeWindow: window.label,
      text: `Good window for outdoor activity (${window.label}). Keep normal precautions and carry the reliever inhaler.`,
    }
  }

  if (window.level === 'caution') {
    return {
      level: 'caution',
      timeWindow: window.label,
      text: `Use caution during ${window.label}. Keep activities shorter and lower intensity.`,
    }
  }

  return {
    level: 'avoid',
    timeWindow: window.label,
    text: `Prefer indoor activities during ${window.label}. Air conditions may trigger symptoms.`,
  }
}

export const handler = async (event) => {
  try {
    const locationParam =
      event?.queryStringParameters?.location?.trim().toLowerCase() ||
      DEFAULT_LOCATION

    const cfg = LOCATION_CONFIG[locationParam] || {
      latitude: DEFAULT_LATITUDE,
      longitude: DEFAULT_LONGITUDE,
      timezone: DEFAULT_TIMEZONE,
    }

    const url =
      `${AIR_API}?latitude=${cfg.latitude}&longitude=${cfg.longitude}` +
      `&hourly=us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide` +
      `&timezone=${encodeURIComponent(cfg.timezone)}`

    const res = await fetch(url)
    if (!res.ok) throw new Error(`Air API failed: ${res.status}`)

    const data = await res.json()
    const times = data?.hourly?.time || []
    const aqiArr = data?.hourly?.us_aqi || []
    const pm25Arr = data?.hourly?.pm2_5 || []
    const pm10Arr = data?.hourly?.pm10 || []
    const ozoneArr = data?.hourly?.ozone || []
    const no2Arr = data?.hourly?.nitrogen_dioxide || []

    if (!times.length) {
      return json(502, { ok: false, message: 'No hourly data from air provider' })
    }

    const today = new Intl.DateTimeFormat('en-CA', {
      timeZone: cfg.timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(new Date())

    const todayHours = []
    for (let i = 0; i < times.length; i++) {
      if (parseDateLocal(times[i]) !== today) continue

      todayHours.push({
        time: times[i],
        hour: parseHourLocal(times[i]),
        aqi: toNumber(aqiArr[i]),
        pm25: toNumber(pm25Arr[i]),
        pm10: toNumber(pm10Arr[i]),
        ozone: toNumber(ozoneArr[i]),
        no2: toNumber(no2Arr[i]),
      })
    }

    if (!todayHours.length) {
      return json(200, {
        ok: true,
        location: locationParam,
        bestWindowLabel: 'No plan available for today',
        windows: [],
        dailyRecommendations: [],
        generatedAt: new Date().toISOString(),
      })
    }

    const windowResults = WINDOWS.map((w) => {
      const rows = todayHours.filter((r) => r.hour >= w.startHour && r.hour < w.endHour)

      if (!rows.length) {
        return {
          label: w.label,
          level: 'caution',
          reason: 'No data available for this window',
          score: 0.6,
        }
      }

      const scores = rows.map((r) => scoreHour(r))
      const score = avg(scores) ?? 0.6
      const avgData = {
        aqi: avg(rows.map((r) => r.aqi)),
        pm25: avg(rows.map((r) => r.pm25)),
        pm10: avg(rows.map((r) => r.pm10)),
        ozone: avg(rows.map((r) => r.ozone)),
        no2: avg(rows.map((r) => r.no2)),
      }

      return {
        label: w.label,
        level: levelFromScore(score),
        reason: reasonFromData(avgData),
        score: Number(score.toFixed(4)),
      }
    })

    const best = [...windowResults].sort((a, b) => a.score - b.score)[0]

    const dailyRecommendations = windowResults
      .map(recommendationFromWindow)
      .sort((a, b) => {
        const order = { avoid: 0, caution: 1, safe: 2 }
        return order[a.level] - order[b.level]
      })

    return json(200, {
      ok: true,
      location: locationParam,
      bestWindowLabel: `Best time: ${best.label}`,
      windows: windowResults.map(({ label, level, reason }) => ({ label, level, reason })),
      dailyRecommendations,
      generatedAt: new Date().toISOString(),
    })
  } catch (err) {
    console.error('get-outdoor-plan failed', err)
    return json(500, {
      ok: false,
      message: 'Internal server error',
    })
  }
}
